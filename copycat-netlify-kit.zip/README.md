# Copycat Netlify Kit

Upload to GitHub then deploy to Netlify.
